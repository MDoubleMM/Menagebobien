# ✅ Checklist Avant Upload sur Serveur

## 🎯 Vérifications à Effectuer Avant d'Uploader

---

## ⚠️ ÉTAPE CRITIQUE - Images

### [ ] 1. Images Copiées dans public/images/

Vérifiez que les 5 images suivantes sont présentes dans `public/images/` :

```
public/images/
├── [ ] promo-avant-apres.jpg      (~66 KB)
├── [ ] office-cleaning.jpg        (~92 KB)
├── [ ] kitchen-cleaning.jpg       (~69 KB)
├── [ ] bathroom-cleaning.jpg      (~52 KB)
└── [ ] window-cleaning.jpg        (~102 KB)
```

**Si NON** : Copiez-les depuis `/images/` (voir IMPORTANT-IMAGES.txt)

---

## 📄 Vérification des Fichiers Principaux

### [ ] 2. Fichiers HTML à la Racine

Vérifiez que ces fichiers sont bien dans `public/` :

#### Pages Principales
- [ ] index.html (page d'accueil)
- [ ] entretien-menager-rive-nord.html
- [ ] blog.html
- [ ] temoignages.html

#### Services (11 pages)
- [ ] menage-residentiel.html
- [ ] menage-commercial.html
- [ ] apres-construction.html
- [ ] grand-menage.html
- [ ] menage-ecologique.html
- [ ] menage-urgence.html
- [ ] fin-de-bail.html
- [ ] nettoyage-vitres.html
- [ ] nettoyage-tapis-planchers.html
- [ ] desinfection.html

#### Spécialisés (3 pages)
- [ ] menage-airbnb.html
- [ ] menage-condos.html
- [ ] menage-bureaux.html

#### Villes (18 pages)
- [ ] entretien-menager-laval.html
- [ ] entretien-menager-repentigny.html
- [ ] entretien-menager-terrebonne.html
- [ ] entretien-menager-blainville.html
- [ ] entretien-menager-boisbriand.html
- [ ] entretien-menager-mascouche.html
- [ ] entretien-menager-rosemere.html
- [ ] entretien-menager-sainte-therese.html
- [ ] entretien-menager-saint-eustache.html
- [ ] entretien-menager-deux-montagnes.html
- [ ] entretien-menager-mirabel.html
- [ ] entretien-menager-oka.html
- [ ] entretien-menager-charlemagne.html
- [ ] entretien-menager-lassomption.html
- [ ] entretien-menager-saint-sulpice.html
- [ ] entretien-menager-bois-des-filion.html
- [ ] entretien-menager-lorraine.html

---

## 🎨 Ressources et Assets

### [ ] 3. Dossiers et Fichiers Requis

- [ ] css/style.css existe
- [ ] js/main.js existe
- [ ] images/ dossier existe avec les 5 images
- [ ] blog/ dossier existe avec 6 articles
- [ ] style.css à la racine existe
- [ ] favicon.ico existe
- [ ] robots.txt existe
- [ ] sitemap.xml existe

---

## 📝 Vérification du Contenu

### [ ] 4. Modifications Récentes Appliquées

Vérifiez que les modifications suivantes sont présentes :

#### Dans index.html (page d'accueil)
- [ ] Le titre est : "Service de Ménage Professionnel sur la Rive-Nord de Montréal"
- [ ] (et NON "à Montréal et Rive-Nord")

#### Dans /index.html (à la racine du projet, pas dans public/)
- [ ] Vérifié que la redirection pointe vers `public/index.html`
- [ ] (et NON vers `public/entretien-menager-rive-nord.html`)

---

## 🔧 Préparation du Serveur

### [ ] 5. Informations Serveur Prêtes

Avant d'uploader, assurez-vous d'avoir :

- [ ] Accès FTP (hôte, username, password)
- [ ] Ou accès cPanel
- [ ] Nom du dossier web sur le serveur (public_html/, www/, htdocs/)
- [ ] Nom de domaine configuré et pointant vers le serveur

---

## 📊 Structure Finale à Uploader

```
Contenu de public/ à uploader vers public_html/:

public_html/                    ← Racine de votre serveur web
├── index.html                  ← PAGE D'ACCUEIL
├── style.css
├── robots.txt
├── sitemap.xml
├── favicon.ico
│
├── css/
│   └── style.css
│
├── js/
│   └── main.js
│
├── images/                     ← VÉRIFIER LES 5 IMAGES !
│   ├── promo-avant-apres.jpg
│   ├── office-cleaning.jpg
│   ├── kitchen-cleaning.jpg
│   ├── bathroom-cleaning.jpg
│   └── window-cleaning.jpg
│
├── blog/                       ← 6 ARTICLES
│   ├── grand-menage-printemps-guide.html
│   ├── produits-menage-ecologiques.html
│   ├── enlever-taches-difficiles.html
│   ├── routine-menage-efficace.html
│   ├── preparer-maison-hiver.html
│   └── hygiene-bureau-productivite.html
│
└── [Tous les fichiers HTML de services et villes]
```

---

## 🚀 Instructions d'Upload

### [ ] 6. Méthode d'Upload Choisie

Choisissez votre méthode :

#### Option A : FTP (FileZilla - Recommandé)
- [ ] FileZilla (ou client FTP) installé
- [ ] Connexion FTP testée
- [ ] Dossier racine identifié (public_html/)

#### Option B : cPanel
- [ ] Accès cPanel disponible
- [ ] Gestionnaire de fichiers accessible
- [ ] Peut uploader tous les fichiers

#### Option C : SSH/SCP (Avancé)
- [ ] Accès SSH disponible
- [ ] Commandes SCP comprises

---

## ✅ Post-Upload - Vérifications

### [ ] 7. Tests Après Upload

Une fois uploadé, testez :

#### Tests de Base
- [ ] https://www.menagebobien.com/ (page d'accueil s'affiche)
- [ ] Les images sont visibles sur la page d'accueil
- [ ] Le CSS fonctionne (design correct)
- [ ] Le menu de navigation fonctionne

#### Tests de Pages
- [ ] Page service : /menage-residentiel.html
- [ ] Page ville : /entretien-menager-laval.html
- [ ] Page blog : /blog.html
- [ ] Article blog : /blog/grand-menage-printemps-guide.html

#### Tests SEO
- [ ] /robots.txt accessible et correct
- [ ] /sitemap.xml accessible et valide
- [ ] Balises meta présentes (View Source)

#### Tests Mobile
- [ ] Site responsive sur smartphone
- [ ] Navigation mobile fonctionne
- [ ] Bouton d'appel cliquable (514-586-9097)

---

## 🔧 En Cas de Problème

### Images ne s'affichent pas ?
→ Vérifiez que les 5 images sont dans public_html/images/
→ Vérifiez les permissions (644 pour fichiers, 755 pour dossiers)

### CSS ne fonctionne pas ?
→ Videz le cache du navigateur (Ctrl+Shift+R)
→ Vérifiez que style.css et css/style.css existent

### Erreur 404 ?
→ Vérifiez que index.html est à la racine de public_html/
→ Vérifiez les noms de fichiers (minuscules)

### Liens cassés ?
→ Vérifiez que tous les fichiers HTML sont à la racine
→ Testez les liens dans plusieurs pages

---

## 📞 Support

Si vous rencontrez des problèmes :

📧 **Email** : menagebobien@hotmail.com
📱 **Téléphone** : 514-586-9097

---

## 🎉 Checklist Complète !

### Avant d'uploader :
- [ ] Images copiées dans public/images/
- [ ] Tous les fichiers HTML présents
- [ ] Dossiers css/, js/, blog/, images/ présents
- [ ] Informations FTP/serveur prêtes

### Pendant l'upload :
- [ ] Connexion FTP établie
- [ ] Upload de TOUT le contenu de public/
- [ ] Upload terminé avec succès

### Après l'upload :
- [ ] Site accessible en ligne
- [ ] Images visibles
- [ ] Navigation fonctionne
- [ ] Tests sur mobile OK
- [ ] SEO files accessibles

---

## ✨ Prêt à Déployer !

Une fois toutes ces cases cochées, votre site web professionnel Ménage Bo-Bien sera en ligne et pleinement opérationnel ! 🚀

**Bonne chance ! 🎊**

---

*Dernière mise à jour : 22 octobre 2025*
*Document : Checklist Pré-Upload*
