# 📦 Installation sur Hostinger - Ménage Bo-Bien

## ✅ Contenu du Dossier Public

Ce dossier contient **TOUT** ce dont vous avez besoin pour déployer votre site sur Hostinger.

```
public/
├── index.html                          ← PAGE D'ACCUEIL
├── favicon.ico                         ← Icône du site (logo BB)
├── robots.txt                          ← Configuration moteurs de recherche
├── sitemap.xml                         ← Sitemap SEO (29 pages)
│
├── 📄 PAGES HTML (28 pages)
├── entretien-menager-rive-nord.html
├── menage-residentiel.html
├── menage-commercial.html
├── apres-construction.html
├── grand-menage.html
├── menage-ecologique.html
├── menage-urgence.html
├── fin-de-bail.html
├── nettoyage-vitres.html
├── nettoyage-tapis-planchers.html
├── desinfection.html
├── entretien-menager-laval.html
├── entretien-menager-repentigny.html
├── entretien-menager-terrebonne.html
├── entretien-menager-blainville.html
├── entretien-menager-boisbriand.html
├── entretien-menager-mascouche.html
├── entretien-menager-rosemere.html
├── entretien-menager-sainte-therese.html
├── entretien-menager-saint-eustache.html
├── entretien-menager-deux-montagnes.html
├── entretien-menager-mirabel.html
├── entretien-menager-oka.html
├── entretien-menager-charlemagne.html
├── entretien-menager-lassomption.html
├── entretien-menager-saint-sulpice.html
├── entretien-menager-bois-des-filion.html
├── entretien-menager-lorraine.html
│
├── 🎨 css/
│   └── style.css                       ← Feuille de style globale
│
├── ⚙️ js/
│   └── main.js                         ← JavaScript (navigation, FAQ, etc.)
│
└── 🖼️ images/                           ← Dossier pour vos images (VIDE)
    └── .gitkeep

```

---

## 🚀 Instructions d'Installation sur Hostinger

### Étape 1: Connexion à Hostinger

1. **Connectez-vous** à votre compte Hostinger: https://hpanel.hostinger.com
2. **Sélectionnez** votre domaine `menagebobien.com`
3. Allez dans **File Manager** (Gestionnaire de fichiers)

### Étape 2: Préparer le Serveur

1. Dans File Manager, allez dans le dossier **`public_html`**
2. **SUPPRIMEZ** tous les fichiers par défaut (index.html, default.html, etc.)
3. Le dossier `public_html` doit être **VIDE**

### Étape 3: Upload des Fichiers

**Option A: Upload via File Manager (Recommandé)**

1. Cliquez sur le bouton **"Upload Files"** (Téléverser des fichiers)
2. Sélectionnez **TOUT** le contenu du dossier `public/`:
   - Tous les fichiers HTML (29 fichiers)
   - Le dossier `css/`
   - Le dossier `js/`
   - Le dossier `images/`
   - `robots.txt`
   - `sitemap.xml`
3. Attendez que l'upload se termine (peut prendre 2-5 minutes)

**Option B: Upload via FTP**

1. Utilisez un client FTP comme **FileZilla**
2. Connectez-vous avec vos identifiants Hostinger FTP
3. Glissez-déposez **TOUT** le contenu de `public/` dans `public_html/`

### Étape 4: Ajouter Vos Images

1. Dans `public_html/images/`, ajoutez vos photos:
   - `og-image.jpg` (image de partage réseaux sociaux, 1200x630px)
   - `kitchen-cleaning.jpg`
   - `bathroom-cleaning.jpg`
   - `office-cleaning.jpg`
   - `window-cleaning.jpg`
   - `promo-avant-apres.jpg`
   - Images des villes: `ville-laval.jpg`, `ville-terrebonne.jpg`, etc.

### Étape 5: Vérifier le Site

1. Ouvrez votre navigateur
2. Visitez: **https://www.menagebobien.com**
3. Vous devriez voir votre page d'accueil!

### Étape 6: Soumettre à Google

1. Allez sur **Google Search Console**: https://search.google.com/search-console
2. Ajoutez votre domaine `www.menagebobien.com`
3. Dans **Sitemaps**, soumettez: `https://www.menagebobien.com/sitemap.xml`

---

## 🎯 Structure Une Fois Installé

```
https://www.menagebobien.com/
├── index.html                          ← https://www.menagebobien.com/
├── entretien-menager-rive-nord.html   ← https://www.menagebobien.com/entretien-menager-rive-nord.html
├── menage-residentiel.html            ← https://www.menagebobien.com/menage-residentiel.html
├── menage-commercial.html             ← https://www.menagebobien.com/menage-commercial.html
└── ... (toutes les autres pages)
```

---

## ✅ Checklist Post-Installation

- [ ] Site accessible sur www.menagebobien.com
- [ ] Toutes les pages se chargent correctement
- [ ] Le CSS fonctionne (design visible)
- [ ] Le JavaScript fonctionne (menu mobile, FAQ)
- [ ] Images ajoutées dans le dossier `images/`
- [ ] SSL/HTTPS activé (cadenas vert dans le navigateur)
- [ ] Sitemap soumis à Google Search Console
- [ ] robots.txt accessible: https://www.menagebobien.com/robots.txt
- [ ] sitemap.xml accessible: https://www.menagebobien.com/sitemap.xml

---

## 🆘 Dépannage

### Le site n'affiche pas le CSS

**Solution:** Vérifiez que le dossier `css/` est bien dans `public_html/css/` et contient `style.css`

### Les images ne s'affichent pas

**Solution:** Ajoutez vos images dans `public_html/images/`

### Erreur 404 sur une page

**Solution:** Vérifiez que tous les fichiers HTML sont bien dans `public_html/` (pas dans un sous-dossier)

### Le menu mobile ne fonctionne pas

**Solution:** Vérifiez que le fichier `js/main.js` existe dans `public_html/js/`

---

## 📞 Support

**Email:** menagebobien@hotmail.com  
**Téléphone:** 514-586-9097

**Domaine:** www.menagebobien.com  
**Hébergeur:** Hostinger

---

## 📊 Informations Techniques

- **Total de pages:** 29 pages HTML
- **Domaine configuré:** www.menagebobien.com
- **Sitemap:** sitemap.xml (29 URLs)
- **Framework:** HTML5 + CSS3 + JavaScript vanilla
- **Responsive:** ✅ Mobile, Tablet, Desktop
- **SEO optimisé:** ✅ Meta tags, Schema.org, URLs canoniques

---

**Date de création:** Octobre 2024  
**Version:** 1.0  
**Statut:** ✅ Production Ready

🎉 **Votre site est prêt à être déployé!**
