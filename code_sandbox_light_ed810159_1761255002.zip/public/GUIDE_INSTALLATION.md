# 🚀 GUIDE D'INSTALLATION - Ménage Bo-Bien

**Version**: 2.0  
**Date**: 2025-10-21  
**Difficulté**: ⭐ Facile (5 minutes)

---

## ✅ MÉTHODE 1: Installation Complète (RECOMMANDÉE)

### Étape 1: Télécharger le Projet
1. Téléchargez tout le dossier `public/` depuis le projet
2. Vous obtenez un dossier contenant tous les fichiers du site

### Étape 2: Téléverser sur Votre Serveur
1. Connectez-vous à votre hébergeur web (cPanel, FTP, etc.)
2. Localisez le dossier racine de votre site:
   - Souvent nommé: `public_html`, `www`, `htdocs`, ou `web`
3. Téléversez **tout le contenu** du dossier `public/` dans ce dossier racine

### Étape 3: Vérifier l'Installation
Visitez votre site:
- **URL**: https://www.menagebobien.com/entretien-menager-rive-nord.html
- Vous devriez voir la page principale du site

### Étape 4: Configurer la Page d'Accueil (Optionnel)
Si vous voulez que `https://www.menagebobien.com/` redirige automatiquement:

**Option A: Créer un index.html**
Créez un fichier `index.html` dans le dossier racine avec ce contenu:
```html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="0; url=entretien-menager-rive-nord.html">
    <title>Ménage Bo-Bien - Redirection</title>
</head>
<body>
    <p>Redirection vers la page principale...</p>
    <script>
        window.location.href = 'entretien-menager-rive-nord.html';
    </script>
</body>
</html>
```

**Option B: Configuration serveur (.htaccess)**
Ajoutez dans le fichier `.htaccess`:
```apache
DirectoryIndex entretien-menager-rive-nord.html
```

✅ **C'est terminé!** Votre site est en ligne.

---

## 🎯 MÉTHODE 2: Installation avec Structure Racine/Public

### Si Vous Voulez Garder la Structure Originale

#### Étape 1: Téléverser
1. Téléversez le fichier `index.html` (racine) dans votre dossier racine serveur
2. Téléversez tout le dossier `public/` dans le même dossier

#### Étape 2: Structure sur le Serveur
```
/public_html/ (ou /www/)
├── index.html                    # Redirige vers public/
└── public/
    ├── entretien-menager-rive-nord.html
    ├── style.css
    ├── sitemap.xml
    ├── tous les autres fichiers...
```

#### Étape 3: Vérifier
- **URL accueil**: https://www.menagebobien.com/ → redirige automatiquement
- **URL directe**: https://www.menagebobien.com/public/entretien-menager-rive-nord.html

---

## 📝 FICHIERS NÉCESSAIRES (Checklist)

### Fichiers HTML (29)
- [ ] entretien-menager-rive-nord.html (page principale)
- [ ] 10 pages services (menage-residentiel.html, etc.)
- [ ] 18 pages villes (entretien-menager-laval.html, etc.)

### Fichiers CSS/JS
- [ ] style.css
- [ ] js/main.js

### Fichiers SEO
- [ ] sitemap.xml
- [ ] robots.txt

### Images (Dossier images/)
- [ ] service-*.jpg (10 images)
- [ ] ville-*.jpg (18 images)
- [ ] og-image.jpg
- [ ] favicon.ico

### Dossiers
- [ ] css/ (contient style.css si séparé)
- [ ] images/ (toutes les images)
- [ ] js/ (contient main.js)

---

## 🔧 CONFIGURATION DNS (Si Nouveau Domaine)

### Chez Votre Registraire de Domaine
1. Connectez-vous à votre compte (ex: GoDaddy, Namecheap, etc.)
2. Accédez aux paramètres DNS de `menagebobien.com`
3. Configurez les enregistrements A:

```
Type    Nom     Valeur (IP de votre serveur)    TTL
A       @       123.456.789.012                  3600
A       www     123.456.789.012                  3600
```

4. Attendez 24-48h pour la propagation DNS

---

## ✅ TESTS POST-INSTALLATION

### Tests à Effectuer
1. **Page principale**: https://www.menagebobien.com/entretien-menager-rive-nord.html
   - [ ] La page s'affiche correctement
   - [ ] Les images sont visibles
   - [ ] Les styles CSS sont appliqués

2. **Navigation interne**:
   - [ ] Cliquez sur un service (ex: Ménage Résidentiel)
   - [ ] Cliquez sur une ville (ex: Laval)
   - [ ] Vérifiez que les liens fonctionnent

3. **Formulaire de contact**:
   - [ ] Testez le formulaire de soumission
   - [ ] Vérifiez la réception de l'email

4. **Responsive mobile**:
   - [ ] Ouvrez le site sur mobile
   - [ ] Vérifiez que le design s'adapte

5. **SEO**:
   - [ ] Sitemap: https://www.menagebobien.com/sitemap.xml
   - [ ] Robots.txt: https://www.menagebobien.com/robots.txt

---

## 🐛 DÉPANNAGE

### Problème: Les Images Ne S'Affichent Pas
**Solution**:
1. Vérifiez que le dossier `images/` est bien téléversé
2. Vérifiez les permissions (755 pour dossiers, 644 pour fichiers)
3. Vérifiez les chemins dans le code HTML

### Problème: Le CSS Ne S'Applique Pas
**Solution**:
1. Vérifiez que `style.css` est dans le bon dossier
2. Videz le cache du navigateur (Ctrl+F5)
3. Vérifiez le chemin dans `<link rel="stylesheet" href="style.css">`

### Problème: Les Liens Ne Fonctionnent Pas
**Solution**:
1. Les liens sont relatifs, vérifiez que tous les fichiers sont au même niveau
2. Vérifiez que les noms de fichiers correspondent exactement (sensible à la casse)

### Problème: Page 404 Not Found
**Solution**:
1. Vérifiez que les fichiers sont dans le bon dossier
2. Vérifiez la configuration du serveur
3. Vérifiez les permissions des fichiers

---

## 📞 CONTACTS FORMSPREE (Formulaire)

### Configuration Actuelle
- **Service**: Formspree
- **ID**: xgvndjdg
- **Endpoint**: https://formspree.io/f/xgvndjdg
- **Email destinataire**: menagebobien@hotmail.com

### Tester le Formulaire
1. Allez sur la page principale
2. Remplissez le formulaire de contact
3. Vérifiez la réception dans `menagebobien@hotmail.com`

---

## 📊 OUTILS SEO RECOMMANDÉS

### Après Installation, Vérifiez:
1. **Google Search Console**
   - Ajoutez votre site
   - Soumettez le sitemap: https://www.menagebobien.com/sitemap.xml

2. **Google PageSpeed Insights**
   - Testez: https://pagespeed.web.dev/
   - URL: https://www.menagebobien.com/entretien-menager-rive-nord.html

3. **Google Mobile-Friendly Test**
   - Vérifiez la compatibilité mobile

4. **Structured Data Testing Tool**
   - Vérifiez le Schema.org (LocalBusiness, FAQPage)

---

## 🎉 FÉLICITATIONS!

Votre site Ménage Bo-Bien est maintenant en ligne! 

### Prochaines Étapes Recommandées
1. ✅ Tester tous les liens et formulaires
2. ✅ Soumettre le sitemap à Google Search Console
3. ✅ Configurer Google Analytics (optionnel)
4. ✅ Monitorer les performances avec PageSpeed Insights
5. ⏳ Enrichir les 9 pages villes restantes (ACTION 10)

---

## 📚 DOCUMENTATION COMPLÈTE

Pour plus d'informations, consultez:
- **README.md** - Documentation complète du projet
- **STRUCTURE_PROJET.md** - Organisation des fichiers
- **RAPPORT_FINAL_SEO_ACTIONS_1-10.md** - Détails optimisations SEO

---

**Support**: Pour toute question, référez-vous à la documentation ou contactez votre développeur web.

**Dernière mise à jour**: 2025-10-21
