# 📁 STRUCTURE DU PROJET - Ménage Bo-Bien

**Date**: 2025-10-21  
**Version**: 2.0 (Réorganisation avec dossier public/)

---

## 🎯 ORGANISATION DES FICHIERS

### Structure Finale
```
/
├── index.html                              # ⚡ RACINE - Redirection vers public/
│
└── public/                                 # 📦 TOUT LE SITE (pour déploiement serveur)
    │
    ├── entretien-menager-rive-nord.html    # 🏠 PAGE PRINCIPALE
    ├── style.css                           # 🎨 Styles globaux
    ├── sitemap.xml                         # 🗺️ Sitemap SEO (38 URLs)
    ├── robots.txt                          # 🤖 Directives robots
    ├── favicon.ico                         # 🎯 Favicon
    │
    ├── css/                                # Styles additionnels (si nécessaire)
    ├── js/                                 # Scripts JavaScript
    │   └── main.js
    ├── images/                             # Toutes les images
    │   ├── service-*.jpg                   # Images services (10)
    │   ├── ville-*.jpg                     # Images villes (18)
    │   └── og-image.jpg                    # Image Open Graph
    │
    ├── Services/ (10 pages HTML)
    │   ├── menage-residentiel.html
    │   ├── menage-commercial.html
    │   ├── grand-menage.html
    │   ├── menage-ecologique.html
    │   ├── menage-urgence.html
    │   ├── fin-de-bail.html
    │   ├── nettoyage-vitres.html
    │   ├── nettoyage-tapis-planchers.html
    │   ├── desinfection.html
    │   └── apres-construction.html
    │
    ├── Villes/ (18 pages HTML)
    │   ├── entretien-menager-laval.html
    │   ├── entretien-menager-terrebonne.html
    │   ├── entretien-menager-repentigny.html
    │   ├── entretien-menager-blainville.html
    │   ├── entretien-menager-boisbriand.html      ✅ Enrichi 500+ mots
    │   ├── entretien-menager-mascouche.html       ✅ Enrichi 560 mots
    │   ├── entretien-menager-rosemere.html        ✅ Enrichi 580 mots (Premium)
    │   ├── entretien-menager-sainte-therese.html  ✅ Enrichi 600 mots
    │   ├── entretien-menager-saint-eustache.html  ✅ Enrichi 620 mots
    │   ├── entretien-menager-deux-montagnes.html  ⏳ À enrichir
    │   ├── entretien-menager-mirabel.html         ⏳ À enrichir
    │   ├── entretien-menager-oka.html             ⏳ À enrichir
    │   ├── entretien-menager-charlemagne.html     ⏳ À enrichir
    │   ├── entretien-menager-lassomption.html     ⏳ À enrichir
    │   ├── entretien-menager-saint-sulpice.html   ⏳ À enrichir
    │   ├── entretien-menager-bois-des-filion.html ⏳ À enrichir
    │   └── entretien-menager-lorraine.html        ⏳ À enrichir
    │
    └── Documentation/
        ├── README.md                               # Documentation principale
        ├── RAPPORT_FINAL_SEO_ACTIONS_1-10.md      # Rapport SEO complet
        ├── PROGRESSION_ACTION_10.md                # Progression enrichissement villes
        ├── ACTIONS_SEO_RAPPORT_FINAL.md           # Actions SEO détaillées
        └── STRUCTURE_PROJET.md                     # Ce fichier
```

---

## 🚀 DÉPLOIEMENT SUR SERVEUR

### Méthode Simple
1. **Télécharger tout le dossier `public/`**
2. **Téléverser sur votre serveur dans le dossier racine ou sous-dossier**
3. **Configurer le domaine pour pointer vers `public/`**

### Configuration Apache (.htaccess)
Si vous placez `public/` à la racine:
```apache
# Redirection automatique vers public/
RewriteEngine On
RewriteCond %{REQUEST_URI} !^/public/
RewriteRule ^(.*)$ /public/$1 [L]
```

### Configuration Nginx
```nginx
location / {
    root /var/www/html/public;
    try_files $uri $uri/ /entretien-menager-rive-nord.html;
}
```

### Option Alternative
Vous pouvez aussi copier tout le contenu de `public/` directement dans le dossier racine du serveur (public_html, www, ou htdocs).

---

## 📄 FICHIERS PRINCIPAUX

### index.html (Racine)
- **Emplacement**: `/index.html`
- **Fonction**: Redirection automatique vers `public/entretien-menager-rive-nord.html`
- **Méthodes**: Meta refresh + JavaScript
- **À modifier**: Uniquement si vous changez la structure

### entretien-menager-rive-nord.html
- **Emplacement**: `public/entretien-menager-rive-nord.html`
- **Fonction**: Page hub principale du site
- **Priority Sitemap**: 1.0 (la plus haute)
- **Contenu**: 
  - Présentation services
  - Liens vers 11 villes principales
  - Liens vers 8 services principaux
  - FAQ complète (10 questions)
  - Témoignages clients
  - Formulaire contact

### sitemap.xml
- **Emplacement**: `public/sitemap.xml`
- **URLs totales**: 38
- **Dernière mise à jour**: 2025-10-21
- **Priorités**:
  - 1.0: Page hub (entretien-menager-rive-nord.html)
  - 0.9: 4 grandes villes
  - 0.8: 10 services
  - 0.7: 14 petites villes

---

## 🔧 CHEMINS D'ACCÈS

### URLs du Site (Production)
- **Domaine**: https://www.menagebobien.com
- **Page d'accueil**: https://www.menagebobien.com/ (redirige vers hub)
- **Hub Rive-Nord**: https://www.menagebobien.com/public/entretien-menager-rive-nord.html
- **Services**: https://www.menagebobien.com/public/menage-residentiel.html
- **Villes**: https://www.menagebobien.com/public/entretien-menager-laval.html

### Liens Internes dans les Pages
Tous les liens dans les fichiers HTML utilisent des chemins relatifs:
```html
<!-- Depuis n'importe quelle page -->
<a href="entretien-menager-rive-nord.html">Accueil</a>
<a href="menage-residentiel.html">Service Résidentiel</a>
<a href="entretien-menager-laval.html">Ménage Laval</a>
```

**⚠️ Important**: Les liens sont relatifs, donc fonctionnent directement tant que tous les fichiers sont dans le même dossier (`public/`).

---

## 📊 INVENTAIRE DES FICHIERS

### Fichiers HTML (29 total)
- ✅ 1 page hub principale
- ✅ 10 pages services
- ✅ 4 pages grandes villes (enrichies)
- ✅ 5 pages villes enrichies (ACTION 10)
- ⏳ 9 pages villes à enrichir

### Fichiers CSS/JS
- ✅ style.css (10.8 KB)
- ✅ main.js (dans js/)

### Images (28+ fichiers)
- ✅ 10 images services (service-*.jpg)
- ✅ 18 images villes (ville-*.jpg)
- ✅ 1 image Open Graph (og-image.jpg)
- ✅ 1 favicon (favicon.ico)

### Fichiers SEO
- ✅ sitemap.xml (8 KB, 38 URLs)
- ✅ robots.txt

### Documentation (5 fichiers)
- ✅ README.md
- ✅ RAPPORT_FINAL_SEO_ACTIONS_1-10.md
- ✅ PROGRESSION_ACTION_10.md
- ✅ ACTIONS_SEO_RAPPORT_FINAL.md
- ✅ STRUCTURE_PROJET.md (ce fichier)

---

## ✅ AVANTAGES DE CETTE STRUCTURE

### 1. Déploiement Simplifié
- ✅ Un seul dossier `public/` à téléverser
- ✅ Aucune modification de chemins nécessaire
- ✅ Fonctionne sur n'importe quel serveur web

### 2. Organisation Claire
- ✅ Séparation racine / contenu
- ✅ Tous les fichiers web dans `public/`
- ✅ Documentation accessible

### 3. Maintenance Facile
- ✅ Structure logique et prévisible
- ✅ Liens relatifs (pas de chemins absolus à modifier)
- ✅ Ajout de nouvelles pages simple

### 4. Performance
- ✅ Fichiers optimisés (lazy loading images)
- ✅ CSS/JS séparés
- ✅ Sitemap optimisé pour crawl rapide

---

## 🔄 MISES À JOUR FUTURES

### Ajouter une Nouvelle Page Ville
1. Créer le fichier dans `public/`: `entretien-menager-nomville.html`
2. Utiliser template Boisbriand ou Mascouche
3. Ajouter URL dans `public/sitemap.xml`
4. Ajouter lien sur page hub `entretien-menager-rive-nord.html`

### Ajouter un Nouveau Service
1. Créer le fichier dans `public/`: `nom-service.html`
2. Ajouter URL dans `public/sitemap.xml` avec priority 0.8
3. Ajouter lien sur page hub

### Modifier le Style
1. Éditer `public/style.css`
2. Tester sur plusieurs pages
3. Vider cache navigateur pour voir changements

---

## 📞 CONTACT & INFORMATIONS

### Entreprise
- **Nom**: Ménage Bo-Bien
- **Téléphone**: 514-586-9097
- **Email**: menagebobien@hotmail.com
- **Secteur**: Rive-Nord de Montréal, Québec

### Formulaire Contact
- **Service**: Formspree
- **ID**: xgvndjdg
- **Endpoint**: https://formspree.io/f/xgvndjdg

---

## 🎯 PROCHAINES ÉTAPES RECOMMANDÉES

1. **PRIORITÉ HAUTE**: Enrichir 9 pages villes restantes (ACTION 10)
   - Deux-Montagnes, Mirabel, Charlemagne, L'Assomption
   - Oka, Saint-Sulpice, Bois-des-Filion, Lorraine
   - Utiliser templates Boisbriand/Mascouche
   - Estimation: 2-3 heures de travail

2. **PRIORITÉ MOYENNE**: Ajouter 2-3 FAQ par page service
   - Impact SEO: Featured snippets potentiels
   - Estimation: 1-2 heures

3. **PRIORITÉ BASSE**: Optimiser anchor texts restants
   - Remplacer "Détails" par textes descriptifs
   - Estimation: 30 minutes

---

**Dernière mise à jour**: 2025-10-21  
**Version**: 2.0  
**Statut**: ✅ Réorganisation complétée, prêt pour déploiement
