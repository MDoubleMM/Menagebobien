# Guide d'Installation sur Serveur Web

## 📦 Contenu du Dossier `public/`

Ce dossier contient **TOUS** les fichiers nécessaires pour votre site web Ménage Bo-Bien.

### Structure des Fichiers

```
public/
├── index.html                          # Page d'accueil principale
├── style.css                           # Fichier CSS principal
├── robots.txt                          # Configuration pour les moteurs de recherche
├── sitemap.xml                         # Plan du site pour le SEO
├── favicon.ico                         # Icône du site
│
├── css/
│   └── style.css                       # Feuille de style (version dossier)
│
├── js/
│   └── main.js                         # JavaScript principal
│
├── images/                             # Images du site
│   ├── kitchen-cleaning.jpg
│   ├── bathroom-cleaning.jpg
│   ├── office-cleaning.jpg
│   ├── window-cleaning.jpg
│   └── promo-avant-apres.jpg
│
├── blog/                               # Articles de blog
│   ├── grand-menage-printemps-guide.html
│   ├── produits-menage-ecologiques.html
│   ├── enlever-taches-difficiles.html
│   ├── routine-menage-efficace.html
│   ├── preparer-maison-hiver.html
│   └── hygiene-bureau-productivite.html
│
├── Pages de services (11 fichiers)
│   ├── menage-residentiel.html
│   ├── menage-commercial.html
│   ├── apres-construction.html
│   ├── grand-menage.html
│   ├── menage-ecologique.html
│   ├── menage-urgence.html
│   ├── fin-de-bail.html
│   ├── nettoyage-vitres.html
│   ├── nettoyage-tapis-planchers.html
│   ├── desinfection.html
│   └── entretien-menager-rive-nord.html
│
├── Pages spécialisées (3 fichiers)
│   ├── menage-airbnb.html
│   ├── menage-condos.html
│   └── menage-bureaux.html
│
├── Pages de villes (18 fichiers)
│   ├── entretien-menager-laval.html
│   ├── entretien-menager-repentigny.html
│   ├── entretien-menager-terrebonne.html
│   ├── entretien-menager-blainville.html
│   ├── entretien-menager-boisbriand.html
│   ├── entretien-menager-mascouche.html
│   ├── entretien-menager-rosemere.html
│   ├── entretien-menager-sainte-therese.html
│   ├── entretien-menager-saint-eustache.html
│   ├── entretien-menager-deux-montagnes.html
│   ├── entretien-menager-mirabel.html
│   ├── entretien-menager-oka.html
│   ├── entretien-menager-charlemagne.html
│   ├── entretien-menager-lassomption.html
│   ├── entretien-menager-saint-sulpice.html
│   ├── entretien-menager-bois-des-filion.html
│   └── entretien-menager-lorraine.html
│
└── Pages supplémentaires
    ├── blog.html                       # Index du blog
    └── temoignages.html                # Page témoignages
```

## 🚀 Instructions d'Installation

### Option 1 : Upload FTP (Recommandé pour la plupart des hébergeurs)

1. **Connectez-vous à votre hébergement via FTP** (FileZilla, Cyberduck, etc.)
   - Hôte : ftp.votredomaine.com
   - Nom d'utilisateur : votre_username
   - Mot de passe : votre_password

2. **Localisez le dossier racine de votre site** (généralement `public_html/`, `www/`, ou `htdocs/`)

3. **Uploadez TOUT le contenu du dossier `public/`** vers la racine de votre site
   - ⚠️ Important : Uploadez le CONTENU du dossier `public/`, pas le dossier lui-même
   - La structure doit être : `public_html/index.html`, `public_html/css/`, etc.

4. **Vérifiez les permissions des fichiers**
   - Fichiers : 644
   - Dossiers : 755

### Option 2 : cPanel (Gestionnaire de fichiers)

1. Connectez-vous à **cPanel**
2. Allez dans **Gestionnaire de fichiers**
3. Naviguez vers le dossier `public_html/`
4. Cliquez sur **Upload** ou **Télécharger**
5. Uploadez tous les fichiers du dossier `public/`
6. Si vous uploadez un fichier ZIP :
   - Décompressez-le dans `public_html/`
   - Supprimez le fichier ZIP après extraction

### Option 3 : SSH (Pour utilisateurs avancés)

```bash
# Connectez-vous via SSH
ssh username@votreserveur.com

# Naviguez vers le dossier web
cd public_html/

# Uploadez vos fichiers (via SCP depuis votre ordinateur local)
scp -r /chemin/vers/public/* username@votreserveur.com:~/public_html/
```

## ✅ Vérification Post-Installation

Après l'upload, vérifiez que votre site fonctionne correctement :

1. **Page d'accueil** : https://www.menagebobien.com/
2. **Test d'une page de service** : https://www.menagebobien.com/menage-residentiel.html
3. **Test d'une page de ville** : https://www.menagebobien.com/entretien-menager-laval.html
4. **Test du blog** : https://www.menagebobien.com/blog.html
5. **Vérifiez robots.txt** : https://www.menagebobien.com/robots.txt
6. **Vérifiez sitemap.xml** : https://www.menagebobien.com/sitemap.xml

## 🔧 Configuration Serveur (Fichier .htaccess)

Si vous utilisez Apache, créez un fichier `.htaccess` dans le dossier racine avec ce contenu :

```apache
# Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Redirection www vers non-www (ou inversement)
RewriteCond %{HTTP_HOST} ^www\.(.*)$ [NC]
RewriteRule ^(.*)$ https://%1/$1 [R=301,L]

# Cache des fichiers statiques
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType text/html "access plus 1 day"
</IfModule>

# Compression GZIP
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

## 📊 Configuration DNS et Google Search Console

### 1. Vérifier la Configuration DNS
Assurez-vous que votre domaine pointe vers votre serveur.

### 2. Google Search Console
1. Allez sur [Google Search Console](https://search.google.com/search-console)
2. Ajoutez votre propriété : `https://www.menagebobien.com`
3. Vérifiez la propriété (méthode HTML recommandée)
4. Soumettez votre sitemap : `https://www.menagebobien.com/sitemap.xml`

### 3. Google Analytics
Le code Google Analytics est déjà intégré dans toutes les pages (ID: G-NYYSJWBWSX)

## 🆘 Dépannage

### Les images ne s'affichent pas
- Vérifiez que le dossier `images/` a été uploadé
- Vérifiez les permissions (755 pour les dossiers, 644 pour les fichiers)
- Vérifiez les chemins dans le navigateur (F12 > Console)

### Les liens ne fonctionnent pas
- Assurez-vous que tous les fichiers HTML sont à la racine
- Vérifiez que les URLs sont en minuscules
- Vérifiez la configuration du serveur (Apache/Nginx)

### Erreur 404
- Vérifiez que `index.html` est bien à la racine
- Vérifiez la configuration du serveur web
- Consultez les logs du serveur

### Le CSS ne se charge pas
- Vérifiez que `style.css` et `css/style.css` existent
- Videz le cache de votre navigateur (Ctrl+Shift+R)
- Vérifiez les permissions des fichiers

## 📞 Contact

Pour toute question technique :
- Email : menagebobien@hotmail.com
- Téléphone : 514-586-9097

## 📝 Notes Importantes

1. **Sauvegarde** : Faites toujours une sauvegarde avant de remplacer des fichiers existants
2. **Cache** : Videz le cache de votre navigateur après chaque modification
3. **SEO** : Ne modifiez pas les balises meta et les URLs sans consulter un expert SEO
4. **Images** : Toutes les images sont déjà optimisées pour le web
5. **Mobile** : Le site est 100% responsive et optimisé pour mobile

## ✨ Site Web Complet et Prêt

Votre site contient maintenant :
- ✅ 1 page d'accueil
- ✅ 11 pages de services
- ✅ 18 pages de villes (SEO local)
- ✅ 3 pages spécialisées
- ✅ 6 articles de blog
- ✅ 1 page témoignages
- ✅ 1 page index blog
- ✅ SEO optimisé
- ✅ Google Analytics intégré
- ✅ Responsive design
- ✅ Sitemap XML
- ✅ Robots.txt

**Total : 42+ pages complètes et optimisées pour le SEO !**

---

**Dernière mise à jour** : 22 octobre 2025
**Version du site** : 2.0
